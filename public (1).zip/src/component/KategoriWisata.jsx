const KategoriWisata = () => {

    return(
        <>
        </>
    )
}

export default KategoriWisata